package com.example.firmadigital;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.firmadigital.clases.Adaptador;
import com.example.firmadigital.clases.Asignaturess;
import com.example.firmadigital.clases.ConexionSQLite;

import java.util.ArrayList;
import java.util.List;

public class List_Firmas extends AppCompatActivity {
    List<Asignaturess> listaItem= new ArrayList<>();
    RecyclerView recyclerViewItem;
    ConexionSQLite sql;
    Adaptador adaptador;
    LinearLayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Lista de firmas digitales");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sql=new ConexionSQLite(this);
        setContentView(R.layout.activity_list_firmas);
        listaItem=sql.getData();
        recyclerViewItem = findViewById(R.id.recycler);
        recyclerViewItem.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerViewItem.setLayoutManager(layoutManager);
        adaptador= new Adaptador(this, listaItem, recyclerViewItem);
        recyclerViewItem.setAdapter(adaptador);
    }
}